+-------------------------------------------------+
|  Secure RMI with Cryptix for remote simulations |
+-------------------------------------------------+


The 'Secure RMI with Cryptix' package provides an example implementation
for secure remote simulations with Renew. It installs a custom socket
factory that encrypts all network data with the DES algorithm implemented
in the Cryptix component. It is ONLY an example, use it as a template
for your own implementations.


Do the following steps to install this package.

- Add Cryptix to your CLASSPATH. You can obtain Cryptix from its homepage,
  http://www.cryptix.org.

- Add Cryptix as a security provider to Java. To do this, run the Install
  tool provided by Cryptix:
  java cryptix.provider.Install

- Unzip this ZIP file into a directory of the CLASSPATH.

- When running Renew, add the Java Virtual Machine property
  de.renew.remote.socketFactory=de.renew.remote.cryptix.DESSocketFactory.
  Add this property as -D option directly after 'java' in the command line.


If you're about to implement your own classes, provide the socket factory
to the above VM property de.renew.remote.socketFactory.
