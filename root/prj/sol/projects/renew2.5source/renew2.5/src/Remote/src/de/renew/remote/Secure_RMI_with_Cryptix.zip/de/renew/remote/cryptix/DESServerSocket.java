package de.renew.remote.cryptix;

import cryptix.provider.*;
import cryptix.provider.cipher.*;
import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import xjava.security.*;


public class DESServerSocket extends ServerSocket
{
	private byte[] key;

	public DESServerSocket(int port, byte[] key)
		throws IOException
	{
		super(port);
		this.key = key;
	}

	public Socket accept()
		throws IOException
	{
		Socket socket = new DESSocket(key);
		implAccept(socket);
		return socket;
	}
}
