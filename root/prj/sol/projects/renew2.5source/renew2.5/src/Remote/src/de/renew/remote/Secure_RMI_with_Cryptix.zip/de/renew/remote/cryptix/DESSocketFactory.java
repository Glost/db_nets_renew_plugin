package de.renew.remote.cryptix;

import cryptix.provider.*;
import cryptix.provider.cipher.*;
import cryptix.util.core.Hex;
import java.io.*;
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import xjava.security.*;


public class DESSocketFactory extends RMISocketFactory implements Serializable
{
	private static final byte[] key = Hex.fromString("3812A419C63BE771");

	public DESSocketFactory()
		throws Exception
	{
	}

	public ServerSocket createServerSocket(int port)
		throws IOException
	{
		return new DESServerSocket(port, key);
	}

	public Socket createSocket(String host, int port)
		throws IOException
	{
		return new DESSocket(host, port, key);
	}
}
